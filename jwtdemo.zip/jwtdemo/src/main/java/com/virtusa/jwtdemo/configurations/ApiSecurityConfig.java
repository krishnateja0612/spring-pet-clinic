package com.virtusa.jwtdemo.configurations;

public class ApiSecurityConfig {

}
